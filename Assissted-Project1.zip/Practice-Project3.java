//method
package methodsjava;
import java.util.*;

public class demomethod {
	public int numbers(int x , int y) {
		int result = x+y ;
		return result;	
		
	}

	public static void main(String[] args) {
		demomethod obj = new demomethod();
		int result = obj.numbers(5,9);
		System.out.println("The value is : " + result);
		
	}

}

// call by value
package methodsjava;
import java.util.*;

public class demomethod {
	int val=2000;

	int operation(int val) {
		val =val*10/100;
		return(val);
	
		
	}

	public static void main(String[] args) {
		demomethod obj = new demomethod();
		
		System.out.println("Before operation value of data is "+obj.val);
		obj.operation(400);
		System.out.println("After operation value of data is "+obj.val);

		
	}

}

//method overloding

package methodsjava;
import java.util.*;

public class demomethod {
	public  void add(int x , int y) {
		System.out.println("Addition is : " + (x+y));
		
	}
	public  void add(int x , int y , int z) {
		System.out.println("Addition is : " + (x+y+z));
	}
	

	public static void main(String[] args) {
		demomethod obj = new demomethod();
		obj.add(10,20);
		obj.add(40,50 ,80);
		
	}

}
