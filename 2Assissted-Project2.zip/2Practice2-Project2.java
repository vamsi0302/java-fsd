Creating a dynamic web project
Pushing the code to your GitHub repositories
Running the project
Publishing and starting the project
Building the project
Checking for servlet-api.jar
Configuring web.xml
Creating a DemoJDBC servlet
Creating a config.properties file to store JDBC credentials
Creating a DBConnection class to initiate a JDBC connection in code
Creating an HTML page index.html
Adding the jar files for MySQL connection for Java