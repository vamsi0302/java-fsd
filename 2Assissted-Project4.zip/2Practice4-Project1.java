<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Simple JSP</title>
</head>
<body>
<%
        out.println("<h2>My first JSP page.</h2>");
%>
</body>
</html>
