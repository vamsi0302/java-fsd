
package filehandling;
import java.io.*;


public class writeappendfile {

	public static void main(String[] args) {
		FileWriter fWrite = null;
		BufferedWriter bWrite = null;
		String addline = "HI , WELCOME THE WORLD OF LIGTH";
		File myFile = new File("myfile.txt");
		
		try{
            if(!(myFile.exists())){
                myFile.createNewFile();
        }
        fWrite = new FileWriter(myFile, true); 
            bWrite = new BufferedWriter(fWrite);
            bWrite.write(addline);
            bWrite.close();
            
            System.out.println("File write complete.....");
            
        }catch (IOException e) {
            e.printStackTrace();
			
		
        }
	}
	}


package filehandling;

import java.io.*;

public class readfiles {

	public static void main(String[] args) {
		try {
            FileReader reader = new FileReader("myfile.txt");
            BufferedReader bufferedReader = new BufferedReader(reader);
 
            String line;
 
            while ((line = bufferedReader.readLine()) != null) {
                System.out.println(line);
            }
            reader.close();
 
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
}
		
		            

 


















