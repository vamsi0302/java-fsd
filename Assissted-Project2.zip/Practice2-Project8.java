//class and objects
class Student {
    
    int id;
    String name;
 
    public static void main(String args[])
    {
        Student s1 = new Student();
        System.out.println(s1.id);
        System.out.println(s1.name);
    }
}

//polymorphism


package methodsjava;
import java.util.*;

public class demomethod {
	public  void add(int x , int y) {
		System.out.println("Addition is : " + (x+y));
		
	}
	public  void add(int x , int y , int z) {
		System.out.println("Addition is : " + (x+y+z));
	}
	

	public static void main(String[] args) {
		demomethod obj = new demomethod();
		obj.add(10,20);
		obj.add(40,50 ,80);
		
	}

}


//inheritance


class Calculation {
   int z;
	
   public void addition(int x, int y) {
      z = x + y;
      System.out.println("The sum of the given numbers:"+z);
   }

}

public class My_Calculation extends Calculation {
   public void multiplication(int x, int y) {
      z = x * y;
      System.out.println("The product of the given numbers:"+z);
   }
	
   public static void main(String args[]) {
      int a = 20, b = 10;
      My_Calculation demo = new My_Calculation();
      demo.addition(a, b);
      demo.multiplication(a, b);
   }
}


//encapsulation


class Area {
  int length;
  int breadth;

  Area(int length, int breadth) {
    this.length = length;
    this.breadth = breadth;
  }
  public void getArea() {
    int area = length * breadth;
    System.out.println("Area: " + area);
  }
}

class Main {
  public static void main(String[] args) {
    Area rectangle = new Area(5, 6);
    rectangle.getArea();
  }
}

































