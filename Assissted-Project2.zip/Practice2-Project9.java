package diamond;

public class abstract Sample {
   public abstract demo();
}

public class Super1 extends Sample{
   public void demo() {
      System.out.println("This is subclass 1");
   }
}
public class Super2 extends Sample{
   public void demo() {
      System.out.println("This is subclass 2");
   }
}

public class SubClass extends Super1, Super2 {
   public static void main(String args[]) {
      SubClass obj = new SubClass();
      obj.demo();
   }
}